from enum import Enum

class Method(Enum):
    CONV = 0
    STRASSEN = 1
    STRASSEN_THRESHOLD = 2